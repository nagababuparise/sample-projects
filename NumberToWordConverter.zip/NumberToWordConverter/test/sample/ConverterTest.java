package sample;

import sample.processor.Converter;
import sample.processor.impl.NumberToWordConverterImpl;
import junit.framework.TestCase;

/**
 * @author naga
 *
 */
public class ConverterTest extends TestCase{
	
	/**
	 * converter
	 */
	Converter converter=new NumberToWordConverterImpl();
	
	 /**
	 * testConversion
	 */
	public void testConversion(){
		   String s=converter.process("1");
	      assertEquals("One", s);
	   }
	   
	   /* (non-Javadoc)
		 * @see junit.framework.TestCase#setUp()
		 */
		protected void setUp(){
		      
		   }

}
