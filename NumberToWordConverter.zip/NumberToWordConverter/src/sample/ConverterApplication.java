package sample;

import java.util.Scanner;

import sample.processor.Converter;
import sample.processor.impl.NumberToWordConverterImpl;

public class ConverterApplication {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Converter converter=new NumberToWordConverterImpl();
		System.out.println("Please enter enter");
		//Reading input from user
		Scanner sc=new Scanner(System.in);
		String str=sc.next();
        System.out.printf("%10s = %s%n", str, converter.process(str));
        
	}

}
