package sample.validator;

import sample.exception.InvalidNumberException;

public class NumberValidator {
	
	public int validate(String number){
		try{
		return Integer.parseInt(number); 
		}catch(Exception e){
			throw new InvalidNumberException("Pleaes enter valid number");
		}
	}

}
