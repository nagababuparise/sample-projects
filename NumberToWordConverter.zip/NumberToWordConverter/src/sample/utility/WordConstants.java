package sample.utility;

/**
 * @author naga
 *
 */
public class WordConstants {
	
	/**
	 * Thousand
	 */
	public static final String 	Thousand=" Thousand";
	
	/**
	 * Million
	 */
	public static final String 	Million=" Million";
	
	/**
	 * Billion
	 */
	public static final String 	Billion=" Billion";
	
	/**
	 * Minus
	 */
	public static final String 	Minus="Minus";
	
	/**
	 * Hundred
	 */
	public static final String 	Hundred=" Hundred";
	
	/**
	 * INT_ZERO
	 */
	public static final int INT_ZERO=0;
	
	/**
	 * INT_TEN
	 */
	public static final int INT_TEN=10;
	
	/**
	 * INT_TWENTY
	 */
	public static final int INT_TWENTY=20;
	
	/**
	 * INT_HUNDRED
	 */
	public static final int INT_HUNDRED=100;
	
	/**
	 * INT_THOUSAND
	 */
	public static final int INT_THOUSAND=1000;
	
	/**
	 * INT_LACK
	 */
	public static final int INT_LACK=1000000;
	
	/**
	 * INT_MILLION
	 */
	public static final int INT_MILLION=1000000000;
	
	/**
	 * INT_BILLION
	 */
	public static final int INT_BILLION=1000000000;
	
	
	/**
	 * units
	 */
	public static final String[] units = {
        "", "One", "Two", "Three", "Four", "Five", "Six", "Seven",
        "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen",
        "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"
        };

    /**
     * tens
     */
    public static final String[] tens = {
        "",        // 0
        "",        // 1
        "Twenty",  // 2
        "Thirty",  // 3
        "Forty",   // 4
        "Fifty",   // 5
        "Sixty",   // 6
        "Seventy", // 7
        "Eighty",  // 8
        "Ninety"   // 9
       };


}
