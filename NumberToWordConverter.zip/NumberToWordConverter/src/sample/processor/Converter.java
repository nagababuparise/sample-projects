/**
 * 
 */
package sample.processor;

/**
 * @author Naga
 *
 */
public interface Converter {
	
	/**
	 * @param number
	 * @return
	 */
	public String convert(final int number);
	
	/**
	 * @param number
	 * @return
	 */
	public String process(String str);


}
