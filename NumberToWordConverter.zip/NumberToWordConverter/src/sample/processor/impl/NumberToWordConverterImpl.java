package sample.processor.impl;

import sample.processor.Converter;
import sample.utility.WordConstants;
import sample.validator.NumberValidator;

/**
 * @author naga
 *
 */
public class NumberToWordConverterImpl implements Converter{
	@Override
	public String process(String str) {
		NumberValidator numberValidator= new NumberValidator();
		numberValidator.validate(str);	
		return convert(numberValidator.validate(str));	
	}
	
	@Override
	public String convert(final int number) {
		if (number < WordConstants.INT_ZERO) {
            return WordConstants.Minus + convert(-number);
        }

        if (number < WordConstants.INT_TWENTY) {
            return WordConstants.units[number];
        }

        if (number < WordConstants.INT_HUNDRED) {
            return WordConstants.tens[number / WordConstants.INT_TEN] + ((number % WordConstants.INT_TEN != 0) ? " " : "") + WordConstants.units[number % WordConstants.INT_TEN];
        }

        if (number < WordConstants.INT_THOUSAND) {
            return WordConstants.units[number / WordConstants.INT_HUNDRED] + WordConstants.Hundred + ((number % WordConstants.INT_HUNDRED != 0) ? " " : "") + convert(number % WordConstants.INT_HUNDRED);
        }

        if (number < WordConstants.INT_LACK) {
            return convert(number / WordConstants.INT_THOUSAND) + WordConstants.Thousand + ((number % WordConstants.INT_THOUSAND != 0) ? " " : "") + convert(number % WordConstants.INT_THOUSAND);
        }

        if (number < WordConstants.INT_MILLION) {
            return convert(number / WordConstants.INT_LACK) + WordConstants.Million+ ((number % WordConstants.INT_LACK != 0) ? " " : "") + convert(number % WordConstants.INT_LACK);
        }

        return convert(number / WordConstants.INT_BILLION) + WordConstants.Billion  + ((number % WordConstants.INT_BILLION != 0) ? " " : "") + convert(number % WordConstants.INT_BILLION);
	}


}
 