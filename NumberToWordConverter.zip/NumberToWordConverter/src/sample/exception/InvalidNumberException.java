package sample.exception;

/**
 * @author naga
 *
 */
public class InvalidNumberException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param message
	 */
	public InvalidNumberException(String message) {
		super(message);
	}

}
